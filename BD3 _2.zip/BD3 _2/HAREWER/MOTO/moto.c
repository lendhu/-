#include "moto.h"


/**************************************************************************
�������ܣ����������ת
��ڲ�����mode   mode=0ʱΪ��ת  mode=1ʱ��ת
����  ֵ����
**************************************************************************/



void moto1(int mode)
{
	if(mode==1)    //��ת
	{
	 GPIO_SetBits(GPIOB, GPIO_Pin_15);	 // �ߵ�ƽ      PB15 --- AIN2      1   
	 GPIO_ResetBits(GPIOB, GPIO_Pin_14);	 // �͵�ƽ}   PB14 --- AIN1      0
	
	 
	
	}
	 if(mode==0)   //����
	{
	 GPIO_SetBits(GPIOB, GPIO_Pin_14);	 // �ߵ�ƽ       PB14 --- AIN1     1
	 GPIO_ResetBits(GPIOB, GPIO_Pin_15);	 // �͵�ƽ}    PB15 --- AIN2     0

	 }
 
}


void moto2(int mode)
{
	if(mode==1)    //��ת
	{
	 
	 GPIO_SetBits(GPIOB, GPIO_Pin_13);     //�ߵ�ƽ   PB13 --- BIN2       1
	 GPIO_ResetBits(GPIOB, GPIO_Pin_12);  // �͵�ƽ   PB12 --- BIN1       0
	
	}
	 if(mode==0)   //����
	{
	
	 GPIO_ResetBits(GPIOB, GPIO_Pin_13);     //�ߵ�ƽ   PB13 --- BIN2     0
	 GPIO_SetBits(GPIOB, GPIO_Pin_12);  // �͵�ƽ   PB12 --- BIN1         1
	 }
 
}


void moto3(int mode)
{
	if(mode==1)    //��ת
	{
	 GPIO_SetBits(GPIOC, GPIO_Pin_1);	 // �ߵ�ƽ      PB15 --- AIN2      1   
	 GPIO_ResetBits(GPIOC, GPIO_Pin_0);	 // �͵�ƽ}   PB14 --- AIN1      0
	
	 
	
	}
	 if(mode==0)   //����
	{
	 GPIO_SetBits(GPIOC, GPIO_Pin_0);	 // �ߵ�ƽ       PB14 --- AIN1     1
	 GPIO_ResetBits(GPIOC, GPIO_Pin_1);	 // �͵�ƽ}    PB15 --- AIN2     0

	 }
 
}


void moto4(int mode)
{
	if(mode==1)    //��ת
	{
	 
	 GPIO_SetBits(GPIOC, GPIO_Pin_3);     //�ߵ�ƽ   PB13 --- BIN2       1
	 GPIO_ResetBits(GPIOC, GPIO_Pin_2);  // �͵�ƽ   PB12 --- BIN1       0
	
	}
	 if(mode==0)   //����
	{
	
	 GPIO_ResetBits(GPIOC, GPIO_Pin_3);     //�ߵ�ƽ   PB13 --- BIN2     0
	 GPIO_SetBits(GPIOC, GPIO_Pin_2);  // �͵�ƽ   PB12 --- BIN1         1
	 }
 
}
