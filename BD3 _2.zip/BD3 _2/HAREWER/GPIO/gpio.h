#ifndef __GPIO_H
#define	__GPIO_H

#include "stm32f10x.h"

void Gpio_Init(void);
void RNSS(char a);
void RDSS(char a);
void EN5V(char a);

#endif

