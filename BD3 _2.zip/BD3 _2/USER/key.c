#include "key.h"
#include "stdio.h"
#include "delay.h"
#include "usart.h"
#include "oled.h"
#include "BD.h"





void KEY_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOC|RCC_APB2Periph_GPIOB,ENABLE);//ʹ��PORTA,PORTCʱ��
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0;//PA0,����KEY_UP
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD; //���ó���������
 	GPIO_Init(GPIOA, &GPIO_InitStructure);//��ʼ��GPIOA0
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9 ;//PC8,PC9
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; //���ó� ��������
 	GPIO_Init(GPIOC, &GPIO_InitStructure);//��ʼ��GPIOC8,9

} 

void KEY(void)
{

		if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0))
		{               
			delay_ms(10);
			while(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0)){};
			delay_ms(10);
			
			fs_flag=1;
			xx_flag=1;
			
		}
		
		if(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_8)==0)
		{               
			delay_ms(10);
			while(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_8)==0){};
			delay_ms(10);
			fs_flag=2;
			xx_flag=2;
		}
		
		
		if(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_9)==0)
		{               
			delay_ms(10);
			while(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_9)==0){};
			delay_ms(10);
	
		}
		
		
			
}


