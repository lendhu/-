#include "ATK.h"
#include "delay.h"
#include "usart.h"	
#include "gpio.h"
#include "BD.h"
#include "string.h"
#include "oled.h"

char *atk1="AT+QHTTPCFG=\"contextid\",1\r\n";
char *atk2="AT+QHTTPCFG=\"responseheader\",1\r\n";
char *atk3="AT+QICSGP=1,1,\"CTNET\",\"\",\"\",1\r\n";
char *atk4="AT+QHTTPURL=32,80\r\n";
char *atk5="http://101.33.208.192:8888/data/\r\n";
char *atk6="AT+QHTTPCFG=\"contenttype\",4\r\n";
char atk7[100];

unsigned char atk8[]="init ok!";

int atk_init_flag=0;





void atk_init(void)
{
	//while(atk_init_flag==0);//�ȴ�ģ���ʼ������ź�
	delay_ms(100);
	SendString(USART3,atk1);//����http��ַ
	delay_ms(100);
	SendString(USART3,atk2);
	delay_ms(100);
	SendString(USART3,atk3);
	delay_ms(100);
	SendString(USART3,atk4);
	delay_ms(100);
	SendString(USART3,atk5);
	delay_ms(100);
	SendString(USART3,atk6);
  delay_ms(100);
	//OLED_ShowString(0,0,atk8,12);//��ʾ��ʼ�����
	//OLED_Refresh();
}


void BD_atk_init_fs(void)
{
	RDSS(0); //����ģ���
	RNSS(0);
	EN5V(1);
	delay_ms(1000);  //�ϵ��ʼ��8s
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	SendString(USART3,atk1);//����http��ַ
	delay_ms(500);
	SendString(USART3,atk2);
	delay_ms(500);
	SendString(USART3,atk3);
	delay_ms(500);
	SendString(USART3,atk4);
	delay_ms(500);
	SendString(USART3,atk5);
	delay_ms(500);
	SendString(USART3,atk6);
  delay_ms(500);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	USART_Cmd(USART2,ENABLE);
	delay_ms(500);
	GET_ZB();
	XX_DB();
	
	sprintf(atk7,"AT+QHTTPPOST=%d,80,80\r\n",changdu(XX_FS_16));
	SendString(USART3,atk7);//4gģ�鷢��
	delay_ms(1000);
	strcpy(atk7, "");
	SendString(USART3,XX_FS_16);//4gģ�鷢��
	strcpy(XX_FS_16, "");
	SendString(USART1,GL_GB);//���ʹر�
	delay_ms(1000);
	SendString(USART1,GL_GB);
	delay_ms(1000);
	SendString(USART1,strCCTCQ);
	delay_ms(1000);
	SendString(USART1,strCCTCQ);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	RDSS(1);
	RNSS(1);
	EN5V(0);
	
}


int changdu(char *a)
{
	int i;
	for(i=0;i<9999;i++)
	{
		if(a[i]=='\0')
		{
			break;
		}
	
	}
	return i;
}





void XX_DB_4G(void)
{
	
}




