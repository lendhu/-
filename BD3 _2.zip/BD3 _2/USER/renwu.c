#include "renwu.h"
#include "usart.h"	
#include "math.h"
#include "oled.h"

int count=0,count1=0,count2=0;
int wz1,wz2,wz3,wz4,wz5,wz6,wz7,wz8,wz9,wz10;
extern int a1,a2,renwu_flag;
extern int p_x[5],p_y[5];
float wy1,wy2,wy3,wy4,wy5,wy6,wy7,wy8,wy9,wy10;
int renwu_4_flag=0;
extern float a3,a4;
int fangxiang=0;


void wyjs()
{
	
	//0->1
	duoji_jisuan(data1,data2,3,0);//����
	wz1=yidong_x;wz2=yidong_y;
	//data1=56;data2=16;data3=81;data4=40;data5=45;data6=75;data7=21;data8=50;
	
	if(data1>data7)
	{
	
	  //1->2
	
			if(data4-data2>0)
		{
			duoji_jisuan(data3,data4,3,1);//����
			wz3=yidong_x;wz4=yidong_y;
		}
		if(data4-data2==0)
		{
			duoji_jisuan(data3,data4,3,0);//��
			wz3=yidong_x;wz4=wz2;

		}			
		
		//2->3
	
	
	if(data5-data3!=0)  
	{
			
		if(data6-data4>0)
		{
			duoji_jisuan(data5,data6,2,1);//����
			wz5=yidong_x;wz6=yidong_y;
		}

	
	}
		if(data5-data3==0)
	{
		
			duoji_jisuan(data5,data6,0,1);//��
			wz6=yidong_y;wz6=wz4;
	
	}
	
	
	//3->4
	

	if(data8-data6<0)
	{
		duoji_jisuan(data7,data8,2,0);//����
		wz7=yidong_x;wz8=yidong_y;
	}
	if(data8-data6==0)
	{
		duoji_jisuan(data7,data8,2,2);//��
		wz7=yidong_x;wz8=wz6;
	}
	
	
	//4->1
	

	if(data1-data7>0)
	{
		duoji_jisuan(data1,data2,3,0);//����
		wz9=yidong_x;wz10=yidong_y;
	}
	if(data8-data6==0)
	{
		duoji_jisuan(data7,data8,0,0);//��
		wz10=yidong_y;wz10=wz8;
	}
	
}
	if(data1<data7)
	{
			//1->2
	
		if(data4-data2<0)
		{
			duoji_jisuan(data3,data4,3,0);//����
			wz3=yidong_x;wz4=yidong_y;
		}
	
		if(data4-data2==0)
		{
			duoji_jisuan(data3,data4,3,0);//��
			wz3=yidong_x;wz4=wz2;

		}			
		
		//2->3
	
	
	if(data5-data3!=0)  
	{
			
		if(data6-data4>0)
		{
			duoji_jisuan(data5,data6,3,1);//����
			wz5=yidong_x;wz6=yidong_y;
		}
	
	}
		if(data5-data3==0)
	{
		
			duoji_jisuan(data5,data6,0,1);//��
			wz6=yidong_y;wz6=wz4;
	
	}
	
	
	//3->4
	
	
	if(data8-data6>0)
	{
		duoji_jisuan(data7,data8,2,1);//����
		wz7=yidong_x;wz8=yidong_y;
	}
	
	if(data8-data6==0)
	{
		duoji_jisuan(data7,data8,2,2);//��
		wz7=yidong_x;wz8=wz6;
	}
	
	
	//4->1
	
	if(data1-data7<0)
	{
		duoji_jisuan(data1,data2,2,0);//����
		wz9=yidong_x;wz10=yidong_y;
	}
	
	if(data8-data6==0)
	{
		duoji_jisuan(data7,data8,0,0);//��
		wz10=yidong_y;wz10=wz8;
	}
	
	}
	
	
	
	wy1=wz3-wz1;
	wy2=wz4-wz2;
	wy3=wz5-wz3;
	wy4=wz6-wz4;
	wy5=wz7-wz5;
	wy6=wz8-wz6;
	wy7=wz9-wz7;
	wy8=wz10-wz8;
	
	
	
	
	
	

	
}



int yidong_x,yidong_y;
 
 void duoji_jisuan(int x,int y,int fx_x,int fx_y)//��0����1����2����3
{
		if(fx_y==0)
	{
		switch (y)
		{
			case 0:yidong_y=18688;break;
			case 1:yidong_y=18681;break;
			case 2:yidong_y=18675;break;
			case 3:yidong_y=18673;break;
			case 4:yidong_y=18672;break;
			case 5:yidong_y=18669;break;
			case 6:yidong_y=18665;break;
			case 7:yidong_y=18661;break;
			case 8:yidong_y=18658;break;
			case 9:yidong_y=18655;break;
			case 10:yidong_y=18652;break;
			case 11:yidong_y=18649;break;
			case 12:yidong_y=18647;break;
			case 13:yidong_y=18645;break;
			case 14:yidong_y=18644;break;
			case 15:yidong_y=18642;break;
			case 16:yidong_y=18638;break;
			case 17:yidong_y=18634;break;
			case 18:yidong_y=18633;break;
			case 19:yidong_y=18631;break;
			case 20:yidong_y=18630;break;
			case 21:yidong_y=18626;break;
			case 22:yidong_y=18624;break;
			case 23:yidong_y=18622;break;
			case 24:yidong_y=18620;break;
			case 25:yidong_y=18619;break;
			case 26:yidong_y=18616;break;
			case 27:yidong_y=18613;break;
			case 28:yidong_y=18610;break;
			case 29:yidong_y=18608;break;
			case 30:yidong_y=18607;break;
			case 31:yidong_y=18605;break;
			case 32:yidong_y=18604;break;
			case 33:yidong_y=18602;break;
			case 34:yidong_y=18600;break;
			case 35:yidong_y=18596;break;
			case 36:yidong_y=18592;break;
			case 37:yidong_y=18588;break;
			case 38:yidong_y=18584;break;
			case 39:yidong_y=18581;break;
			case 40:yidong_y=18579;break;
			case 41:yidong_y=18578;break;
			case 42:yidong_y=18575;break;
			case 43:yidong_y=18572;break;
			case 44:yidong_y=18570;break;
			case 45:yidong_y=18569;break;
			case 46:yidong_y=18566;break;
			case 47:yidong_y=18563;break;
			case 48:yidong_y=18562;break;
			case 49:yidong_y=18560;break;
			case 50:yidong_y=18559;break;
			case 51:yidong_y=18554;break;
			case 52:yidong_y=18553;break;
			case 53:yidong_y=18551;break;
			case 54:yidong_y=18550;break;
			case 55:yidong_y=18548;break;
			case 56:yidong_y=18546;break;
			case 57:yidong_y=18543;break;
			case 58:yidong_y=18541;break;
			case 59:yidong_y=18539;break;
			case 60:yidong_y=18537;break;
			case 61:yidong_y=18535;break;
			case 62:yidong_y=18529;break;
			case 63:yidong_y=18527;break;
			case 64:yidong_y=18524;break;
			case 65:yidong_y=18521;break;
			case 66:yidong_y=18519;break;
			case 67:yidong_y=18516;break;
			case 68:yidong_y=18513;break;
			case 69:yidong_y=18508;break;
			case 70:yidong_y=18504;break;
			case 71:yidong_y=18503;break;
			case 72:yidong_y=18501;break;
			case 73:yidong_y=18500;break;
			case 74:yidong_y=18499;break;
			case 75:yidong_y=18497;break;
			case 76:yidong_y=18496;break;
			case 77:yidong_y=18494;break;
			case 78:yidong_y=18492;break;
			case 79:yidong_y=18490;break;
			case 80:yidong_y=18487;break;
			case 81:yidong_y=18485;break;
			case 82:yidong_y=18483;break;
			case 83:yidong_y=18481;break;
			case 84:yidong_y=18480;break;
			case 85:yidong_y=18478;break;
			case 86:yidong_y=18473;break;
			case 87:yidong_y=18471;break;
			case 88:yidong_y=18470;break;
			case 89:yidong_y=18468;break;
		  case 90:yidong_y=18466;break;
			case 91:yidong_y=18461;break;
			case 92:yidong_y=18458;break;
			case 93:yidong_y=18456;break;
			case 94:yidong_y=18455;break;
			case 95:yidong_y=18454;break;
			case 96:yidong_y=18451;break;
			case 97:yidong_y=18448;break;
			case 98:yidong_y=18445;break;
			case 99:yidong_y=18443;break;
		  case 100:yidong_y=18435;break;
	}
		
	
	

}
		if(fx_y==1)
	{
		switch (y)
		{
			case 1:yidong_y=18669;break;
			case 2:yidong_y=18665;break;
			case 3:yidong_y=18660;break;
			case 4:yidong_y=18656;break;
			case 5:yidong_y=18658;break;
			case 6:yidong_y=18651;break;
			case 7:yidong_y=18645;break;
			case 8:yidong_y=18643;break;
			case 9:yidong_y=18641;break;
			case 10:yidong_y=18639;break;
			case 11:yidong_y=18636;break;
			case 12:yidong_y=18634;break;
			case 13:yidong_y=18632;break;
			case 14:yidong_y=18630;break;
			case 15:yidong_y=18627;break;
			case 16:yidong_y=18623;break;
			case 17:yidong_y=18621;break;
			case 18:yidong_y=18619;break;
			case 19:yidong_y=18616;break;
			case 20:yidong_y=18613;break;
			case 21:yidong_y=18610;break;
			case 22:yidong_y=18608;break;
			case 23:yidong_y=18606;break;
			case 24:yidong_y=18604;break;
			case 25:yidong_y=18602;break;
			case 26:yidong_y=18601;break;
			case 27:yidong_y=18600;break;
			case 28:yidong_y=18597;break;
			case 29:yidong_y=18593;break;
			case 30:yidong_y=18590;break;
			case 31:yidong_y=18588;break;
			case 32:yidong_y=18585;break;
			case 33:yidong_y=18582;break;
			case 34:yidong_y=18579;break;
			case 35:yidong_y=18575;break;
			case 36:yidong_y=18573;break;
			case 37:yidong_y=18571;break;
			case 38:yidong_y=18569;break;
			case 39:yidong_y=18568;break;
			case 40:yidong_y=18566;break;
			case 41:yidong_y=18564;break;
			case 42:yidong_y=18561;break;
			case 43:yidong_y=18558;break;
			case 44:yidong_y=18555;break;
			case 45:yidong_y=18554;break;
			case 46:yidong_y=18552;break;
			case 47:yidong_y=18550;break;
			case 48:yidong_y=18549;break;
			case 49:yidong_y=18542;break;
			case 50:yidong_y=18540;break;
			case 51:yidong_y=18539;break;
			case 52:yidong_y=18537;break;
			case 53:yidong_y=18535;break;
			case 54:yidong_y=18533;break;
			case 55:yidong_y=18531;break;
			case 56:yidong_y=18528;break;
			case 57:yidong_y=18528;break;
			case 58:yidong_y=18524;break;
			case 59:yidong_y=18522;break;
			case 60:yidong_y=18520;break;
			case 61:yidong_y=18518;break;
			case 62:yidong_y=18515;break;
			case 63:yidong_y=18513;break;
			case 64:yidong_y=18511;break;
			case 65:yidong_y=18509;break;
			case 66:yidong_y=18507;break;
			case 67:yidong_y=18500;break;
			case 68:yidong_y=18497;break;
			case 69:yidong_y=18494;break;
			case 70:yidong_y=18491;break;
			case 71:yidong_y=18488;break;
			case 72:yidong_y=18485;break;
			case 73:yidong_y=18483;break;
			case 74:yidong_y=18482;break;
			case 75:yidong_y=18480;break;
			case 76:yidong_y=18478;break;
			case 77:yidong_y=18477;break;
			case 78:yidong_y=18475;break;
			case 79:yidong_y=18473;break;
			case 80:yidong_y=18470;break;
			case 81:yidong_y=18468;break;
			case 82:yidong_y=18466;break;
			case 83:yidong_y=18463;break;
			case 84:yidong_y=18461;break;
			case 85:yidong_y=18459;break;
			case 86:yidong_y=18457;break;
			case 87:yidong_y=18454;break;
			case 88:yidong_y=18452;break;
			case 89:yidong_y=18450;break;
		  case 90:yidong_y=18448;break;
			case 91:yidong_y=18446;break;
			case 92:yidong_y=18444;break;
			case 93:yidong_y=18442;break;
			case 94:yidong_y=18440;break;
			case 95:yidong_y=18437;break;
			case 96:yidong_y=18435;break;
			case 97:yidong_y=18432;break;
			case 98:yidong_y=18429;break;
			case 99:yidong_y=18435;break;
		  case 100:yidong_y=18410;break;
	}
		
	
	

}
	if(fx_x==2)
	{
		switch (x)
		{
			case 0:yidong_x=18220;break;
			case 1:yidong_x=18222;break;
			case 2:yidong_x=18224;break;
			case 3:yidong_x=18227;break;
			case 4:yidong_x=18230;break;
			case 5:yidong_x=18233;break;
			case 6:yidong_x=18236;break;
			case 7:yidong_x=18237;break;
			case 8:yidong_x=18239;break;
			case 9:yidong_x=18241;break;
			case 10:yidong_x=18243;break;
			case 11:yidong_x=18245;break;
			case 12:yidong_x=18247;break;
			case 13:yidong_x=18249;break;
			case 14:yidong_x=18252;break;
			case 15:yidong_x=18254;break;
			case 16:yidong_x=18256;break;
			case 17:yidong_x=18258;break;
			case 18:yidong_x=18260;break;
			case 19:yidong_x=18262;break;
			case 20:yidong_x=18264;break;
			case 21:yidong_x=18266;break;
			case 22:yidong_x=18270;break;
			case 23:yidong_x=18272;break;
			case 24:yidong_x=18274;break;
			case 25:yidong_x=18276;break;
			case 26:yidong_x=18277;break;
			case 27:yidong_x=18283;break;
			case 28:yidong_x=18284;break;
			case 29:yidong_x=18285;break;
			case 30:yidong_x=18286;break;
			case 31:yidong_x=18289;break;
			case 32:yidong_x=18293;break;
			case 33:yidong_x=18295;break;
			case 34:yidong_x=18298;break;
			case 35:yidong_x=18300;break;
			case 36:yidong_x=18302;break;
			case 37:yidong_x=18304;break;
			case 38:yidong_x=18307;break;
			case 39:yidong_x=18309;break;
			case 40:yidong_x=18311;break;
			case 41:yidong_x=18313;break;
			case 42:yidong_x=18314;break;
			case 43:yidong_x=18315;break;
			case 44:yidong_x=18316;break;
			case 45:yidong_x=18318;break;
			case 46:yidong_x=18320;break;
			case 47:yidong_x=18322;break;
			case 48:yidong_x=18325;break;
			case 49:yidong_x=18327;break;
			case 50:yidong_x=18329;break;
			case 51:yidong_x=18331;break;
			case 52:yidong_x=18333;break;
			case 53:yidong_x=18335;break;
			case 54:yidong_x=18337;break;
			case 55:yidong_x=18339;break;
			case 56:yidong_x=18341;break;
			case 57:yidong_x=18343;break;
			case 58:yidong_x=18344;break;
			case 59:yidong_x=18346;break;
			case 60:yidong_x=18348;break;
			case 61:yidong_x=18350;break;
			case 62:yidong_x=18352;break;
			case 63:yidong_x=18355;break;
			case 64:yidong_x=18358;break;
			case 65:yidong_x=18361;break;
			case 66:yidong_x=18364;break;
			case 67:yidong_x=18366;break;
			case 68:yidong_x=18368;break;
			case 69:yidong_x=18369;break;
			case 70:yidong_x=18371;break;
			case 71:yidong_x=18372;break;
			case 72:yidong_x=18374;break;
			case 73:yidong_x=18376;break;
			case 74:yidong_x=18378;break;
			case 75:yidong_x=18380;break;
			case 76:yidong_x=18382;break;
			case 77:yidong_x=18384;break;
			case 78:yidong_x=18386;break;
			case 79:yidong_x=18389;break;
			case 80:yidong_x=18393;break;
			case 81:yidong_x=18395;break;
			case 82:yidong_x=18397;break;
			case 83:yidong_x=18400;break;
			case 84:yidong_x=18403;break;
			case 85:yidong_x=18405;break;
			case 86:yidong_x=18406;break;
			case 87:yidong_x=18407;break;
			case 88:yidong_x=18408;break;
			case 89:yidong_x=18409;break;
		  case 90:yidong_x=18410;break;
			case 91:yidong_x=18412;break;
			case 92:yidong_x=18415;break;
			case 93:yidong_x=18419;break;
			case 94:yidong_x=18426;break;
			case 95:yidong_x=18429;break;
			case 96:yidong_x=18433;break;
			case 97:yidong_x=18435;break;
			case 98:yidong_x=18437;break;
			case 99:yidong_x=18439;break;
		  case 100:yidong_x=18441;break;
	}
		
	
	

}
	

if(fx_x==3)
	{
		switch (x)
		{
			case 0:yidong_x=18228;break;
			case 1:yidong_x=18232;break;
			case 2:yidong_x=18235;break;
			case 3:yidong_x=18242;break;
			case 4:yidong_x=18244;break;
			case 5:yidong_x=18246;break;
			case 6:yidong_x=18248;break;
			case 7:yidong_x=18249;break;
			case 8:yidong_x=18254;break;
			case 9:yidong_x=18256;break;
			case 10:yidong_x=18258;break;
			case 11:yidong_x=18261;break;
			case 12:yidong_x=18263;break;
			case 13:yidong_x=18265;break;
			case 14:yidong_x=18267;break;
			case 15:yidong_x=18269;break;
			case 16:yidong_x=18271;break;
			case 17:yidong_x=18272;break;
			case 18:yidong_x=18274;break;
			case 19:yidong_x=18277;break;
			case 20:yidong_x=18280;break;
			case 21:yidong_x=18282;break;
			case 22:yidong_x=18284;break;
			case 23:yidong_x=18286;break;
			case 24:yidong_x=18287;break;
			case 25:yidong_x=18290;break;
			case 26:yidong_x=18292;break;
			case 27:yidong_x=18294;break;
			case 28:yidong_x=18296;break;
			case 29:yidong_x=18298;break;
			case 30:yidong_x=18300;break;
			case 31:yidong_x=18302;break;
			case 32:yidong_x=18306;break;
			case 33:yidong_x=18309;break;
			case 34:yidong_x=18312;break;
			case 35:yidong_x=18314;break;
			case 36:yidong_x=18316;break;
			case 37:yidong_x=18317;break;
			case 38:yidong_x=18318;break;
			case 39:yidong_x=18320;break;
			case 40:yidong_x=18321;break;
			case 41:yidong_x=18322;break;
			case 42:yidong_x=18324;break;
			case 43:yidong_x=18326;break;
			case 44:yidong_x=18328;break;
			case 45:yidong_x=18330;break;
			case 46:yidong_x=18332;break;
			case 47:yidong_x=18334;break;
			case 48:yidong_x=18336;break;
			case 49:yidong_x=18338;break;
			case 50:yidong_x=18340;break;
			case 51:yidong_x=18342;break;			
			case 52:yidong_x=18345;break;		
			case 53:yidong_x=18347;break;
			case 54:yidong_x=18349;break;
			case 55:yidong_x=18351;break;
			case 56:yidong_x=18353;break;		
			case 57:yidong_x=18355;break;
			case 58:yidong_x=18357;break;
			case 59:yidong_x=18359;break;
			case 60:yidong_x=18361;break;
			case 61:yidong_x=18362;break;
			case 62:yidong_x=18363;break;
			case 63:yidong_x=18364;break;
			case 64:yidong_x=18368;break;
			case 65:yidong_x=18371;break;
			case 66:yidong_x=18374;break;
			case 67:yidong_x=18377;break;
			case 68:yidong_x=18379;break;
			case 69:yidong_x=18380;break;
			case 70:yidong_x=18382;break;
			case 71:yidong_x=18385;break;
			case 72:yidong_x=18388;break;
			case 73:yidong_x=18390;break;
			case 74:yidong_x=18393;break;
			case 75:yidong_x=18396;break;
			case 76:yidong_x=18397;break;
			case 77:yidong_x=18398;break;
			case 78:yidong_x=18399;break;
			case 79:yidong_x=18401;break;
			case 80:yidong_x=18403;break;
			case 81:yidong_x=18407;break;
			case 82:yidong_x=18410;break;
			case 83:yidong_x=18412;break;
			case 84:yidong_x=18414;break;
			case 85:yidong_x=18416;break;
			case 86:yidong_x=18417;break;
			case 87:yidong_x=18420;break;
			case 88:yidong_x=18423;break;
			case 89:yidong_x=18426;break;
		  case 90:yidong_x=18428;break;
			case 91:yidong_x=18429;break;
			case 92:yidong_x=18430;break;
			case 93:yidong_x=18430;break;
			case 94:yidong_x=18434;break;
			case 95:yidong_x=18440;break;
			case 96:yidong_x=18444;break;
			case 97:yidong_x=18445;break;
			case 98:yidong_x=18458;break;
			case 99:yidong_x=18452;break;
		  case 100:yidong_x=18454;break;
	}
		
	
	

}
	

		
}
 
 
 void renwu_0()
{
//	a1=18200;
//	a2=18200;
//	count++;
//	if(count>=30)
//	{
//		count=0;
//		a1=18435;a2=18650;
//	  renwu_flag=99;
//	}
	a1=18250;
	a2=18450;
	count++;
	if(count>=20)
	{
		count=0;
		a1=18340;
	  a2=18555;
	  renwu_flag=99;
	}
	
}
void renwu_1()
{
	count++;
	if(count>=10)
	{
		count=0;
		count1++;
		count1=count1%4;
	}
	switch(count1)
	{
		
		case 0:a1=18250;a2=18450;break;
		case 1:a1=18400;a2=18450;break;
		case 2:a1=18400;a2=18600;break;
		case 3:a1=18250;a2=18600;break;
		
	}
}
void renwu_2()
{
	count++;
	if(count>=20)
	{
		count=0;
		count1++;
		count1=count1%4;
	}
	switch(count1)
	{
		
		case 0:a1=18440;a2=18658;break;
		case 3:a1=18234;a2=18658;break;
		case 2:a1=18234;a2=18438;break;
		case 1:a1=18435;a2=18438;break;
		
	}
}

void renwu_3()
{
	count++;
	if(count>=20)
	{
		count=0;
		count1++;
		count1=count1%4;
	}
	switch(count1)
	{
		
		case 0:a1=18242;a2=18655;break;
		case 1:a1=18353;a2=18655;break;
		case 2:a1=18353;a2=18563;break;
		case 3:a1=18242;a2=18563;break;
		
			
//		case 0:a1=18220;a2=18580;break;
//		case 3:a1=18338;a2=18580;break;
//		case 2:a1=18338;a2=18673;break;
//		case 1:a1=18220;a2=18665;break;
//		case 4:count1=0;renwu_flag=99;break;
	}
}


void renwu_4()
{
	if(count2<100)
	{
	  a1=18100;
	  a2=18200;
		count2++;
		wyjs();
	}

	if(count2==100)
	{
		count2=200;		
	  a1=wz1;a2=wz2;
		renwu_4_flag=1;
		a3=a1;
		a4=a2;
		
	}
}

