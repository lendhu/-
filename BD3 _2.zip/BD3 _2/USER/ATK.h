#ifndef __ATK_H
#define __ATK_H

extern int atk_init_flag;
int changdu(char *a);

void BD_atk_init_fs(void);
void XX_DB_4G(void);
void atk_init(void);

#endif




