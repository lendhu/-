#ifndef __KEY_H
#define __KEY_H	 
#include "sys.h"



extern char i;

 
 void KEY_Init(void);
 void KEY(void);
					    
#endif


