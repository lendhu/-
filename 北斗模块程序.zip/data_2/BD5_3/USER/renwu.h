#ifndef __RENWU_H
#define __RENWU_H	 


extern int count,count1;
extern int renwu_4_flag;
extern float wy1,wy2,wy3,wy4,wy5,wy6,wy7,wy8,wy9,wy10;
extern int wz1,wz2,wz3,wz4,wz5,wz6,wz7,wz8,wz9,wz10;
extern int yidong_x,yidong_y;
void renwu_0(void);
void renwu_1(void);
void renwu_2(void);
void renwu_3(void);
void renwu_4(void);
 void duoji_jisuan(int x,int y,int fx_x,int fx_y);//��0����1����2����3
void wyjs(void);

#endif
