#ifndef __CONTROL_H_
#define __CONTROL_H_


#define LEFT_POS 8
#define RIGHT_POS 3


typedef struct
{
         float  Kp;                  // �������� Proportional Const
         float  Ki;                  // ���ֳ��� Integral Const
         float  Kd;                  // ΢�ֳ��� Derivative Const
         float  Integral;
         float  Bias;
         float  Last_Bias;
         float  Pre_Bias;
}PID_TypDef;

extern PID_TypDef Motor_pid_2;
extern PID_TypDef Motor_pid_1;        //�ҵ��pid
extern PID_TypDef Steer_pid_1;
extern PID_TypDef Steer_pid_2;
extern int pwm_x,pwm_y;

void PID_init(PID_TypDef* sptr);   //===PID��ֵ��ʼ��
void PID_Set(PID_TypDef *PID,float Kp,float Ki,float Kd);   //===PID��ֵ����
float IncPID(int Encoder,int Target,PID_TypDef* sptr);      //===����ʽpid
float PstPID(float Angle, float Target,PID_TypDef* sptr);   //===λ��ʽPId
int LOWPID(int a,int Target);


#endif
