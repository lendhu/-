#ifndef __485_H
#define __485_H

#include "stm32f10x.h"


void zhuanhuan_wendu(char a,char b);
void zhuanhuan_shidu(char a,char b);
void OLED_Showdata(void);
void send_int16_t(int16_t num);
void get_485(void);
void get_qixiang(void);


extern char WD[10],SD[10];
	

#endif

