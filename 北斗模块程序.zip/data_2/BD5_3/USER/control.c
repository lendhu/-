#include "control.h"

PID_TypDef Motor_pid_1;   
PID_TypDef Motor_pid_2;   
PID_TypDef Steer_pid_1;
PID_TypDef Steer_pid_2;

int lstcs_r = 50,lstcs_r1=40;
int lstcs_l = 85,lstcs_l1=50;

int r_speed;
int l_speed;
int pwm_x,pwm_y;


extern int pwm_flag;

//��ʼ��PID
void PID_init(PID_TypDef* sptr)
{
    sptr->Kp = 0.0;             // �������� Proportional Const
    sptr->Ki = 0.0;             // ���ֳ��� Integral Const
    sptr->Kd = 0.0;             // ΢�ֳ��� Derivative Const
    sptr->Bias      = 0.0;
    sptr->Integral  = 0.0;
    sptr->Last_Bias = 0.0;
    sptr->Pre_Bias  = 0.0;

}

//PID����
void PID_Set(PID_TypDef *PID,float Kp,float Ki,float Kd)
{
    PID->Kp = Kp;
    PID->Ki = Ki;
    PID->Kd = Kd;
}
//P

//����ʽPID
float IncPID(int Encoder,int Target,PID_TypDef* sptr)
{
  float Pwm;
  sptr->Bias = Target - Encoder;                                     // ���㵱ǰ���(Ŀ��ֵ-��������ֵ)
  Pwm = sptr->Kp * (sptr->Bias-sptr->Last_Bias)                      // P*(��ǰ���-�ϴ����)
         +sptr->Ki * sptr->Bias                                      // I*���
         +sptr->Kd * (sptr->Bias-2*sptr->Last_Bias+sptr->Pre_Bias);  // D*(��ǰ���-2*�ϴ����+���ϴ����)
//  printf("p=%f,i=%f,d=%f\r\n",sptr->Kp * (sptr->Bias-sptr->Last_Bias),sptr->Ki * sptr->Bias,sptr->Kd * (sptr->Bias-2*sptr->Last_Bias+sptr->Pre_Bias));
  sptr->Pre_Bias=sptr->Last_Bias;                                    // �洢���ϴ����
  sptr->Last_Bias=sptr->Bias;                                        // �洢�ϴ����

	

  return(Pwm);                                    // ��������ֵ

}


//λ��ʽPID
float PstPID(float Angle, float Target,PID_TypDef* sptr)
{
    float Pwm;

    sptr->Bias = Target -Angle ;
    if(sptr->Bias<=5&&sptr->Bias>=-5)sptr->Bias=0;
    sptr->Integral += sptr->Bias;

    Pwm = sptr->Kp   * sptr->Bias                   // P
         +sptr->Ki * sptr->Integral                 // I
         +sptr->Kd * (sptr->Bias-sptr->Last_Bias);  // D

    sptr->Last_Bias=sptr->Bias;
	if(Target - Angle==0)
	{
	Pwm=0;
	}
	if(Pwm>=1)
	{
		Pwm=1;
	}
	if(Pwm<=-1)
	{
	Pwm=-1;
	}

    //printf("%.2f  %.2f\r\n",Pwm,Angle);
    return(Pwm);

}

int LOWPID(int a,int Target)
{
	int err=Target-a;
	float Pwm=0;
	if(err>0 )
	{
		Pwm+=1;
	}
	if(err<0)
	{
		Pwm-=1;
	}
	
	return(Pwm);
}









