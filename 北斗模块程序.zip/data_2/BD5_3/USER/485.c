#include "485.h"
#include "stm32f10x.h"
#include "delay.h"
#include "usart.h"
#include "string.h"
#include "OLED.h"
char WD[10];//�¶�
char SD[10];//ʪ��


void send_int16_t(int16_t num)
{
	
	uint8_t high_8, low_8;
	low_8 = num & 0x00FF;
	high_8 = (num>>8) & 0x00FF;
	USART_SendData(USART3,high_8);
	USART_SendData(USART3,low_8);

}


void zhuanhuan_wendu(char a,char b)
{
	int c1,c2,c3,c4,c5,c6;
	float c7;
	unsigned int jg=0;
	c1=((int)a)/16;
	c2=((int)a)%16;
	c3=((int)b)/16;
	c4=((int)b)%16;
  jg=c1*16*16*16+c2*16*16+c3*16+c4;
	c5=jg/10000;	
	c6=jg%10000;
	
	if(c5==1)
		c7=c6/10.0;
	if(c5==2)
		c7=c6/100.0;
	if(c5==3)
		c7=c6/1000.0;
	if(c5==4)
		c7=c6/10000.0;
	if(c5!=0)
		c7=(c7/249.0*1000-4)*7.5-40;
	strcpy(WD,"");
	sprintf(WD,"%.2f",c7);

//	WD[0]=(int)c7;
//	WD[1]='.';
//	WD[2]=((int)((c7-(int)c7)*1000))/100;
//	WD[3]=((int)(((int)((c7-(int)c7)*1000))-WD[2]*1000))/10;
}


void zhuanhuan_shidu(char a,char b)
{
	int c1,c2,c3,c4,c5,c6;
	float c7;
	unsigned int jg=0;
	c1=((int)a)/16;
	c2=((int)a)%16;
	c3=((int)b)/16;
	c4=((int)b)%16;
  jg=c1*16*16*16+c2*16*16+c3*16+c4;
	c5=jg/10000;	
	c6=jg%10000;
	
	if(c5==1)
		c7=c6/10.0;
	if(c5==2)
		c7=c6/100.0;
	if(c5==3)
		c7=c6/1000.0;
	if(c5==4)
		c7=c6/10000.0;
	if(c5!=0)
		c7=(c7/249.0*1000-4)*6.25;
	strcpy(SD,"");
	sprintf(SD,"%.2f",c7);
	


//	SD[0]=(int)c7;
//	SD[1]='.';
//	SD[2]=((int)((c7-(int)c7)*1000))/100;
//	SD[3]=((int)(((int)((c7-(int)c7)*1000))-SD[2]*1000))/10;
	
	
}


void get_485(void)
{	
	GPIO_WriteBit(GPIOB,GPIO_Pin_9,(BitAction)1);
	delay_ms(50);
	send_int16_t(0x01);
	delay_ms(2);
	send_int16_t(0x04);
	delay_ms(2);
	send_int16_t(0x00);
	delay_ms(2);
	send_int16_t(0x00);
	delay_ms(2);
	send_int16_t(0x00);
	delay_ms(2);
	send_int16_t(0x08);
	delay_ms(2);
	send_int16_t(0xf1);
	delay_ms(2);
	send_int16_t(0xcc);
	delay_ms(2);
	GPIO_WriteBit(GPIOB,GPIO_Pin_9,(BitAction)0);
	delay_ms(2000);
}

void get_qixiang(void)
{	
	GPIO_WriteBit(GPIOB,GPIO_Pin_9,(BitAction)1);
	delay_ms(50);
	send_int16_t(0x01);
	delay_ms(2);
	send_int16_t(0x03);
	delay_ms(2);
	send_int16_t(0x00);
	delay_ms(2);
	send_int16_t(0x00);
	delay_ms(2);
	send_int16_t(0x00);
	delay_ms(2);
	send_int16_t(0x07);
	delay_ms(2);
	send_int16_t(0x04);
	delay_ms(2);
	send_int16_t(0x08);
	delay_ms(2);
	GPIO_WriteBit(GPIOB,GPIO_Pin_9,(BitAction)0);
	delay_ms(2000);
}


