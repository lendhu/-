#include "gpio.h"

void Gpio_Init(void)
{
		
  GPIO_InitTypeDef GPIO_InitStructure;   
  GPIO_InitTypeDef GPIO_InitStructure1;  	
	GPIO_InitTypeDef GPIO_InitStructure2;           
	
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE); 
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);  
	
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14;	 //����PA11 ˮ��PA12
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;  
	GPIO_Init(GPIOA, &GPIO_InitStructure);   

  GPIO_InitStructure1.GPIO_Pin =  GPIO_Pin_8;	 
  GPIO_InitStructure1.GPIO_Mode = GPIO_Mode_Out_PP;     	  
  GPIO_InitStructure1.GPIO_Speed = GPIO_Speed_50MHz;  
	GPIO_Init(GPIOA, &GPIO_InitStructure1); 

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;	//�����������
  GPIO_Init(GPIOB, &GPIO_InitStructure);
 
	GPIO_InitStructure2.GPIO_Pin =  GPIO_Pin_12| GPIO_Pin_13|GPIO_Pin_14;	           //����ģ������
  GPIO_InitStructure2.GPIO_Mode = GPIO_Mode_Out_PP;     	
  GPIO_InitStructure2.GPIO_Speed = GPIO_Speed_50MHz; 
	GPIO_Init(GPIOB, &GPIO_InitStructure2);          
	
}


void RNSS(char a)
{
	GPIO_WriteBit(GPIOB,GPIO_Pin_13,(BitAction)a);
}

void RDSS(char a)
{
	GPIO_WriteBit(GPIOB,GPIO_Pin_12,(BitAction)a);
}

void EN5V(char a)
{
	GPIO_WriteBit(GPIOB,GPIO_Pin_14,(BitAction)a);
}





